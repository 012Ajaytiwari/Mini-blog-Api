
import React from 'react';

const SignUp = () => {
  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <form className="bg-white p-6 rounded shadow-md w-80">
        <h2 className="text-2xl mb-4 font-bold text-center">Sign Up</h2>
        <input type="text" placeholder="Full Name" className="block w-full mb-2 p-2 border rounded" />
        <input type="email" placeholder="Email" className="block w-full mb-2 p-2 border rounded" />
        <input type="password" placeholder="Password" className="block w-full mb-2 p-2 border rounded" />
        <button className="w-full bg-blue-500 text-white p-2 rounded">Sign Up</button>
      </form>
    </div>
  );
};

export default SignUp;
