
import React from 'react';

const BlogList = () => {
  const blogs = Array(6).fill({
    title: 'Sample Blog Title',
    summary: 'This is a sample blog description',
    image: 'https://via.placeholder.com/150'
  });

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Blog Page</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {blogs.map((blog, index) => (
          <div key={index} className="border rounded shadow-md p-4">
            <img src={blog.image} alt="blog" className="w-full h-40 object-cover mb-2 rounded" />
            <h2 className="text-xl font-semibold">{blog.title}</h2>
            <p className="text-sm text-gray-600">{blog.summary}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BlogList;
